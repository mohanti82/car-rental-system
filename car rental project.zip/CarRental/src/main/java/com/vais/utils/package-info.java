/**
 * 
 */
/**
 * @author Eduard
 *
 */
package com.vais.utils;
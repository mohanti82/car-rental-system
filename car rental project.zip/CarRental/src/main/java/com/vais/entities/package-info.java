/**
 * 
 */
/**
 * @author Eduard
 *
 */
package com.vais.entities;
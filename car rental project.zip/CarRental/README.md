
### Web application for car rental service. 
### Application based on:
 * Spring Boot, Spring Security, PostgreSQL, JPA/Hibernate. 
 * As FE - JSP, CSS, HTML, JavaScript
